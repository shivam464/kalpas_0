import logo from './logo.svg';
import './App.css';
import Cutom_joinery from './Pages/Cutom_joinery';

function App() {
  return (
    <div className="App">
      <Cutom_joinery/>
    </div>
  );
}

export default App;
