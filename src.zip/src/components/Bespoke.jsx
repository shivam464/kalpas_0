import React from 'react'

const Bespoke = () => {
    return (
        <div className='bespoke_main_div'>
            <div className='container bespoke_container justify-content-center  align-item-center text-center ' style={{ padding:"2rem 0" }}>
                <h2 className='m-0 '>Bespoke Joinery Services</h2>
                <h6>RESIDENTAL HOSPITALITY CONTRACT</h6>
                <div className=' d-flex justify-content-center'>
                    <div className='text-muted besopke_div text-start' style={{ padding: "0 5rem",maxWidth:"60rem"}}>
                        <div className='container'>
                            <div className='row'>
                                <div className='col-sm-12 col-md-12' >
                                    <p >Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cupiditate temporibus, numquam ratione sit tempora quae asperiores illo
                                        repudiandae doloribus reiciendis Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum porro ab voluptates tempore rem odit neque beatae deserunt ducimus voluptas? soluta deserunt, reprehenderit enim perferendis aliquid, molestiae inventore autem ipsa consequatur distinctio tempore rerum ipsum harum! Quibusdam est, culpa similique veniam perspiciatis voluptas corporis optio
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default Bespoke
