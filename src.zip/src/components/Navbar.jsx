import React from 'react'

const Navbar = () => {
    return (
        <div>
            <nav class="navbar navbar-light bg-light ">
                <div class="container-fluid justify-content-center">
                    <a class="navbar-brand " href="#">BEUMUNT</a>
                </div>
            </nav>
        </div>
    )
}

export default Navbar
